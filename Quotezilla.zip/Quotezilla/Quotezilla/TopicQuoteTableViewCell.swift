//
//  TopicQuoteTableViewCell.swift
//  Quotezilla
//
//  Created by MacBook Pro on 24/01/2024.
//

import UIKit

protocol TopicQuoteTableViewCellDelegate: AnyObject {
    func favoriteButtonTapped(at indexPath: IndexPath)
}
class TopicQuoteTableViewCell: UITableViewCell {
    
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var quoteLabel: UILabel!
    @IBOutlet weak var favoriteButton: UIButton!
    @IBOutlet weak var authorLabel: UILabel!
    
    weak var delegate: TopicQuoteTableViewCellDelegate?
    var indexPath: IndexPath?
    
    @IBAction func favoriteButtonTapped(_ sender: UIButton) {
        if let indexPath = self.indexPath, let delegate = delegate {
            delegate.favoriteButtonTapped(at: indexPath)
        }
        updateFavoriteButtonAppearance()
        
        
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setupUI()
    }
    
    func updateFavoriteButtonAppearance() {
        if let indexPath = self.indexPath {
            let selectedQuote = QuotesData.shared.quotes[indexPath.section]
            
            let isFavorite = QuotesData.shared.favoriteQuotes.contains {
                $0.quote == selectedQuote.quote && $0.author == selectedQuote.author
            }
            
            let imageName = isFavorite ? "heart.fill.red" : "heart"
            let image = UIImage(named: imageName)
            
            favoriteButton.setImage(image, for: .normal)
        }
    }
    
    func setupUI() {
        containerView.layer.cornerRadius = 40
        containerView.layer.borderWidth = 1
        containerView.layer.borderColor = UIColor.lightGray.cgColor
    }
    
    func setRandomBackgroundColor(_ color: UIColor) {
        if contentView.backgroundColor == nil {
            contentView.backgroundColor = color
        }
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        contentView.backgroundColor = nil
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
}
extension UIColor {
    static func randomLightColorss() -> UIColor {
        let randomRed = CGFloat(drand48() * 0.5 + 0.5)
        let randomGreen = CGFloat(drand48() * 0.5 + 0.5)
        let randomBlue = CGFloat(drand48() * 0.5 + 0.5)
        return UIColor(red: randomRed, green: randomGreen, blue: randomBlue, alpha: 1.0)
    }
}

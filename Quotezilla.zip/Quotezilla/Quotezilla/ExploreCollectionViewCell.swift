//
//  ExploreCollectionViewCell.swift
//  Quotezilla
//
//  Created by MacBook Pro on 19/01/2024.
//

import UIKit

class ExploreCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var categoryLabel: UILabel!
    
}

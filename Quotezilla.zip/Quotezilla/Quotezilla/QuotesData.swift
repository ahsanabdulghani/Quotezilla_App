//
//  QuotesData.swift
//  Quotezilla
//
//  Created by 4STAR on 14/01/2024.


import Foundation

struct Quote: Decodable {
    let quote: String
    let author: String
    let profession: String
    let topics: [String]
}

class QuotesData {
    static let shared = QuotesData()
    var favoriteQuotes: [Quote] = []
    var quotes: [Quote] = []
    
    private init() {
        loadQuotesFromJSON()
    }
    func addQuote(_ quote: Quote) {
        var newQuote = quote
        quotes.append(newQuote)
    }
    
    private func loadQuotesFromJSON() {
        guard let path = Bundle.main.path(forResource: "Quotes", ofType: "json"),
              let data = try? Data(contentsOf: URL(fileURLWithPath: path)),
              let quotesArray = try? JSONSerialization.jsonObject(with: data, options: []) as? [[String: Any]] else {
            return
        }
        
        quotes = quotesArray.compactMap { quoteDict in
            guard
                let quote = quoteDict["quote"] as? String,
                let author = quoteDict["author"] as? String,
                let profession = quoteDict["profession"] as? String,
                let topics = quoteDict["topics"] as? [String]
            else {
                return nil
            }
            
            return Quote(quote: quote, author: author, profession: profession, topics: topics)
        }
    }
    func addFavorite(_ quote: Quote) {
        if !favoriteQuotes.contains(where: { $0.quote == quote.quote && $0.author == quote.author }) {
            favoriteQuotes.append(quote)
        }    }
    
}


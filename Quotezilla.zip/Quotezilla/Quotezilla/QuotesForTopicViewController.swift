//
//  QuotesForTopicViewController.swift
//  Quotezilla
//
//  Created by MacBook Pro on 24/01/2024.
//

import UIKit

class QuotesForTopicViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, TopicQuoteTableViewCellDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    
    var randomBackgroundColors: [Int: UIColor] = [:]
    
    var selectedTopic: String?
    var filteredQuotes: [Quote] = []
    
    let cellSpacingHeight: CGFloat = 20
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        tableView.delegate = self
        tableView.separatorStyle = .none
        
        tableView.estimatedRowHeight = 300
        tableView.rowHeight = 300
        
        print("QuotesForTopicViewController - ViewDidLoad")
        
        if let selectedTopic = selectedTopic {
            print("Selected Topic: \(selectedTopic)")
            
            filteredQuotes = QuotesData.shared.quotes.filter { quote in
                return quote.topics.contains(selectedTopic)
            }
            
            print("Filtered Quotes: \(filteredQuotes)")
        }
        
        tableView.reloadData()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()
    }
    
    // MARK: - UITableViewDataSource
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return filteredQuotes.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "TopicQuoteCell", for: indexPath) as? TopicQuoteTableViewCell else {
            fatalError("Unable to dequeue QuoteTableViewCell")
        }
        
        let quote = filteredQuotes[indexPath.section]
        cell.quoteLabel.text = quote.quote
        cell.authorLabel.text = quote.author
        cell.indexPath = indexPath
        cell.delegate = self
        
        cell.updateFavoriteButtonAppearance()
        
        if let color = randomBackgroundColors[indexPath.section] {
            cell.setRandomBackgroundColor(color)
        } else {
            let randomColor = UIColor.randomLightColor()
            randomBackgroundColors[indexPath.section] = randomColor
            cell.setRandomBackgroundColor(randomColor)
        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return cellSpacingHeight
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor = UIColor.clear
        return headerView
    }
    
    func favoriteButtonTapped(at indexPath: IndexPath) {
        let selectedQuote = filteredQuotes[indexPath.section]
        
        if let index = QuotesData.shared.favoriteQuotes.firstIndex(where: {
            $0.quote == selectedQuote.quote && $0.author == selectedQuote.author
        }) {
            QuotesData.shared.favoriteQuotes.remove(at: index)
        } else {
            QuotesData.shared.addFavorite(selectedQuote)
            
            if let cell = tableView.cellForRow(at: indexPath) as? QuoteTableViewCell,
               let color = cell.contentView.backgroundColor {
                NotificationCenter.default.post(name: NSNotification.Name("FavoriteQuoteColorUpdated"), object: color)
            }
        }
        
        tableView.reloadData()
        
    }
}

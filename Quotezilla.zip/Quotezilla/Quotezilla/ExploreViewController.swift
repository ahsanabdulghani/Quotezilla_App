//
//  ExploreViewController.swift
//  Quotezilla
//
//  Created by MacBook Pro on 19/01/2024.
//

import UIKit

class ExploreViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    var quotes: [Quote] = []
    var uniqueTopics: [String] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        collectionView.dataSource = self
        collectionView.delegate = self
        
        if let layout = collectionView.collectionViewLayout as? UICollectionViewFlowLayout {
            layout.minimumInteritemSpacing = 0
            layout.minimumLineSpacing = 5
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let allTopics = Set(QuotesData.shared.quotes.flatMap { $0.topics })
        
        uniqueTopics = Array(allTopics)
        quotes = QuotesData.shared.quotes
        collectionView.reloadData()
    }
    
    // MARK: - UICollectionViewDataSource
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return uniqueTopics.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ExploreCollectionViewCell", for: indexPath) as? ExploreCollectionViewCell else {
            fatalError("Unable to dequeue TopicCell")
        }
        
        guard indexPath.item < uniqueTopics.count else {
            cell.categoryLabel.text = ""
            return cell
        }
        
        let uniqueTopic = uniqueTopics[indexPath.item]
        
        cell.categoryLabel.text = uniqueTopic
        
        let mediumColors: [UIColor] = [
            UIColor(red: 0.8, green: 0.8, blue: 1.0, alpha: 1.0),
            UIColor(red: 0.8, green: 1.0, blue: 0.8, alpha: 1.0),
            UIColor(red: 1.0, green: 0.8, blue: 0.8, alpha: 1.0),
            UIColor(red: 0.9, green: 0.9, blue: 0.7, alpha: 1.0),
            UIColor(red: 0.7, green: 0.9, blue: 0.9, alpha: 1.0),
        ]
        
        cell.backgroundColor = mediumColors[indexPath.item % mediumColors.count]
        
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let collectionViewWidth = collectionView.bounds.width
        let cellWidth = collectionViewWidth / 2 - 5 // Adjust according to your desired spacing
        let cellHeight: CGFloat = 400
        return CGSize(width: cellWidth, height: cellHeight)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard indexPath.item < uniqueTopics.count else {
            return
        }
        
        let selectedTopic = uniqueTopics[indexPath.item]
        
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            if let exploreVC = self.navigationController?.visibleViewController as? ExploreViewController {
                exploreVC.performSegue(withIdentifier: "showQuotesForTopic", sender: selectedTopic)
            } else {
                self.performSegue(withIdentifier: "showQuotesForTopic", sender: selectedTopic)
            }
        }
    }
    // MARK: - Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showQuotesForTopic", let selectedTopic = sender as? String {
            if let destinationVC = segue.destination as? QuotesForTopicViewController {
                destinationVC.selectedTopic = selectedTopic
            }
        }
    }
    
}


//
//  FavoriteTableViewCell.swift
//  Quotezilla
//
//  Created by 4STAR on 15/01/2024.
//

import UIKit
protocol FavoriteTableViewCellDelegate: AnyObject {
    func favoriteButtonTapped(at indexPath: IndexPath)
}

class FavoriteTableViewCell: UITableViewCell {
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var favoriteQuoteLabel: UILabel!
    
    @IBOutlet weak var favoriteButton: UIButton!
    @IBOutlet weak var authorLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setupUI()
    }
    weak var delegate: FavoriteTableViewCellDelegate?
    var indexPath: IndexPath?
    
    @IBAction func favoriteButtonTapped(_ sender: UIButton) {
        
        if let indexPath = self.indexPath, let delegate = delegate {
            delegate.favoriteButtonTapped(at: indexPath)
        }
        
    }
    func updateFavoriteButtonAppearance() {
        if let indexPath = self.indexPath {
            let selectedQuote = QuotesData.shared.quotes[indexPath.section]
            
            let isFavorite = QuotesData.shared.favoriteQuotes.contains {
                $0.quote == selectedQuote.quote && $0.author == selectedQuote.author
            }
            
            let imageName = isFavorite ? "heart.fill.red" : "heart"
            let image = UIImage(named: imageName)
            
            favoriteButton.setImage(image, for: .normal)
        }
    }
    func setRandomBackgroundColor(_ color: UIColor) {
        if contentView.backgroundColor == nil {
            contentView.backgroundColor = color
        }
    }
    
    
    func setupUI() {
        containerView.layer.cornerRadius = 40
        containerView.layer.borderWidth = 1
        containerView.layer.borderColor = UIColor.lightGray.cgColor
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}

extension UIColor {
    static func randomLightColors() -> UIColor {
        let randomRed = CGFloat(drand48() * 0.5 + 0.5)
        let randomGreen = CGFloat(drand48() * 0.5 + 0.5)
        let randomBlue = CGFloat(drand48() * 0.5 + 0.5)
        return UIColor(red: randomRed, green: randomGreen, blue: randomBlue, alpha: 1.0)
    }
}

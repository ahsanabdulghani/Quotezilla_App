//
//  ViewController.swift
//  Quotezilla
//
//  Created by 4STAR on 05/01/2024.
//

// ViewController.swift



import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var backgroundImage: UIImageView!
    @IBOutlet weak var goto: UIButton!
    @IBOutlet weak var imgviewbutton: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        startForwardMovingAnimation()
    }
    
    func startForwardMovingAnimation() {
        goto.transform = CGAffineTransform(translationX: -view.bounds.width, y: 0)
        imgviewbutton.transform = CGAffineTransform(translationX: -view.bounds.width, y: 0)
        
        UIView.animate(withDuration: 1.0, delay: 0.0, options: .curveEaseInOut, animations: {
            self.goto.transform = CGAffineTransform.identity
            self.imgviewbutton.transform = CGAffineTransform.identity
        }, completion: nil)
    }
    
    @IBAction func goto(_ sender: UIButton) {
        performSegue(withIdentifier: "toAllQuotes", sender: self)
    }
}


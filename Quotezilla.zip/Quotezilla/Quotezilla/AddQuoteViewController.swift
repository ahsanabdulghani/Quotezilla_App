//
//  AddQuoteViewController.swift
//  Quotezilla
//
//  Created by MacBook Pro on 12/01/2024.
//

import UIKit

class AddQuoteViewController: UIViewController {
    
    @IBOutlet weak var quoteTextField: UITextField!
    @IBOutlet weak var authorTextField: UITextField!
    @IBOutlet weak var professionTextField: UITextField!
    @IBOutlet weak var topicTextField: UITextField!
    var collectionIdentifier: String?
    
    var newQuote: String?
    
    @IBAction func saveQuote(_ sender: UIButton) {
        guard let quoteText = quoteTextField.text,!quoteText.isEmpty,
              let authorText = authorTextField.text,!authorText.isEmpty,
              let professionText = professionTextField.text,!professionText.isEmpty,
              let topicText = topicTextField.text,!professionText.isEmpty else {
            
            return
        }
        
        let newQuote = Quote(quote: quoteText, author: authorText, profession: professionText, topics: [topicText])
        QuotesData.shared.addQuote(newQuote)
        print("quote is \(newQuote)")
        performSegue(withIdentifier: "unwindToAllQuote", sender: self)
    }
}

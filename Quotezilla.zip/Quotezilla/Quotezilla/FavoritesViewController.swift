//
//  FavoritesViewController.swift
//  Quotezilla
//
//  Created by MacBook Pro on 12/01/2024.
//

import UIKit

class FavoritesViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, FavoriteTableViewCellDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    
    var randomBackgroundColors: [Int: UIColor] = [:]
    
    
    let cellReuseIdentifier = "favoriteCell"
    let cellSpacingHeight: CGFloat = 20
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        tableView.separatorStyle = .none
        tableView.estimatedRowHeight = 300
        tableView.rowHeight = 300
        
        NotificationCenter.default.addObserver(self, selector: #selector(handleFavoriteQuoteColorUpdated(_:)), name: NSNotification.Name("FavoriteQuoteColorUpdated"), object: nil)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func handleFavoriteQuoteColorUpdated(_ notification: Notification) {
        if let color = notification.object as? UIColor {
            
            randomBackgroundColors[0] = color
            
            
            
            tableView.reloadData()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()
    }
    func favoriteButtonTapped(at indexPath: IndexPath) {
        let selectedQuote = QuotesData.shared.favoriteQuotes[indexPath.row]
        
        QuotesData.shared.favoriteQuotes.remove(at: indexPath.row)
        
        tableView.reloadData()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return QuotesData.shared.favoriteQuotes.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: cellReuseIdentifier, for: indexPath) as? FavoriteTableViewCell else {
            fatalError("Unable to dequeue FavoriteTableViewCell")
        }
        
        let favoriteQuote = QuotesData.shared.favoriteQuotes[indexPath.row]
        cell.favoriteQuoteLabel.text = favoriteQuote.quote
        cell.authorLabel.text = favoriteQuote.author
        cell.indexPath = indexPath
        cell.delegate = self
        
        cell.updateFavoriteButtonAppearance()
        
        if let color = randomBackgroundColors[indexPath.section] {
            cell.setRandomBackgroundColor(color)
        } else {
            let randomColor = UIColor.randomLightColors()
            randomBackgroundColors[indexPath.section] = randomColor
            cell.setRandomBackgroundColor(randomColor)
        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return cellSpacingHeight
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor = UIColor.clear
        return headerView
    }
    
    
}
